package com.nura.autoaccept

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

class AcceptAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Placeholder: supplied snippet does not implement Accept detection or clicking.
    }
    override fun onInterrupt() {}
}
