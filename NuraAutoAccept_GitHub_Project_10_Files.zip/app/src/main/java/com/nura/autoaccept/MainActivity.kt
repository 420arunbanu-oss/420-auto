package com.nura.autoaccept

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 60, 40, 40)
        }
        layout.addView(TextView(this).apply {
            text = "Nura Auto Accept"
            textSize = 24f
        })
        layout.addView(TextView(this).apply {
            text = "Enable the accessibility service in Android Settings. Automatic Accept clicking is not implemented in the supplied service yet."
            textSize = 16f
            setPadding(0, 24, 0, 24)
        })
        layout.addView(Button(this).apply {
            text = "Enable Accessibility"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        setContentView(layout)
    }
}
