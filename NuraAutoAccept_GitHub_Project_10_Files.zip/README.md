# Nura Auto Accept

Android Kotlin starter project assembled from the 10 snippets provided.

## Build APK on GitHub
1. Extract this ZIP.
2. Upload the contents, including the `.github` folder, to the root of a GitHub repository on the `main` branch.
3. Open **Actions** and run **Build APK**, or push a commit to `main`.
4. Download the `app-release` artifact from the completed workflow.

## Important
The supplied `AcceptAccessibilityService.kt` has an empty event handler. Automatic Accept detection/clicking is not implemented in the 10 snippets. This ZIP organizes the project and adjusts the workflow to use installed Gradle, but it does not yet auto-click Accept.

The project does not include `gradlew`; the workflow uses the Gradle setup action and installed Gradle command.
