SMARTDRIVO — ANDROID PHONE TO GITHUB
====================================
இந்த ZIP-ஐ Android ஃபோனிலிருந்து GitHub-க்கு முழு project-ஆக upload செய்ய Termux பயன்படுத்தலாம்.

1. Android-ல் Termux-ஐ நிறுவவும் (அதிகாரப்பூர்வ F-Droid அல்லது Termux GitHub release).
2. ZIP-ஐ Download folder-ல் சேமிக்கவும்.
3. Termux திறந்து இயக்கவும்:
   termux-setup-storage
   pkg update
   pkg install git unzip
4. Download folder-க்கு சென்று ZIP-ஐ extract செய்யவும்:
   cd ~/storage/downloads
   unzip smartdrivo-android-github-upload.zip -d smartdrivo-project
   cd smartdrivo-project
   குறிப்பு: ZIP-ஐ வேறு பெயரில் சேமித்திருந்தால் command-ல் பெயரை மாற்றவும்.
5. GitHub-ல் புதிய காலியான repository உருவாக்கவும். README/license சேர்க்காமல் உருவாக்கினால் எளிது.
6. இந்த project root folder-ல் இயக்கவும்:
   bash push-to-github.sh
7. கேட்கும் போது GitHub repository HTTPS URL-ஐ paste செய்யவும்.
   GitHub password கேட்கும் இடத்தில் account password அல்ல; Personal Access Token (PAT) பயன்படுத்தவும்.
   Token-ஐ யாருடனும் பகிர வேண்டாம்; code-க்குள் எழுத வேண்டாம்.

முக்கியம்:
- ஏற்கெனவே கோப்புகள் உள்ள repository-க்கு push செய்தால் conflict/rejected push வரலாம்.
- இந்த project build இங்கு இயக்கிச் சோதிக்கப்படவில்லை.
- Firebase/Razorpay secrets, signing keys போன்றவற்றை GitHub-க்கு commit செய்யாதீர்கள்.
