package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.MembershipPlan
import com.example.ui.theme.AccentGreen
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun PlanSelectionScreen(
    plans: List<MembershipPlan> =
        MembershipPlan.DEFAULT_PLANS,
    currentPlanId: String = "7DAYS",
    currentPlanPrice: Int = 0,
    planExpireMillis: Long = 0L,
    isCurrentPlanActive: Boolean = false,
    isAdmin: Boolean = false,
    onPlanSelected: (plan: MembershipPlan) -> Unit,
    onBack: (() -> Unit)? = null
) {
    val currentPlan = plans.firstOrNull {
        it.id == currentPlanId
    }

    val uriHandler = LocalUriHandler.current

    // FREE_TRIAL_UI_POLISH_V4
    val isFreeTrial =
        currentPlanId.equals(
            "FREE_TRIAL",
            ignoreCase = true
        )
    var selectedPlan by remember(currentPlanId, plans) {
        mutableStateOf(
            currentPlan ?: plans.firstOrNull { it.id == "7DAYS" } ?: plans.first()
        )
    }

    val now = System.currentTimeMillis()
    val oneDayMs = 24L * 60L * 60L * 1000L

    val remainingDays = remember(planExpireMillis, isAdmin) {
        if (isAdmin) {
            -1
        } else {
            val diff = planExpireMillis - System.currentTimeMillis()

            if (diff <= 0L) {
                0
            } else {
                ((diff + oneDayMs - 1L) / oneDayMs).toInt()
            }
        }
    }

    val expiryText = remember(planExpireMillis) {
        if (planExpireMillis > 0L) {
            SimpleDateFormat(
                "dd MMM yyyy",
                Locale.getDefault()
            ).format(Date(planExpireMillis))
        } else {
            "Not available"
        }
    }

    val hasActiveMembership =
        isAdmin || isCurrentPlanActive

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF8FAFC))
    ) {

        // ----------------------------------------------------
        // HEADER
        // ----------------------------------------------------
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.White)
                .padding(
                    horizontal = 12.dp,
                    vertical = 12.dp
                ),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (onBack != null) {
                IconButton(
                    onClick = { onBack.invoke() }
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = Color(0xFF0F172A)
                    )
                }
            }

            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = if (hasActiveMembership)
                        "My Membership"
                    else
                        "Choose Membership",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF0F172A)
                )

                Text(
                    text = if (hasActiveMembership)
                        "Current plan, remaining days & renewal"
                    else
                        "Select a plan to activate SmartDrivo",
                    fontSize = 13.sp,
                    color = Color(0xFF64748B)
                )
            }
        }


        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {

            item {
                Spacer(modifier = Modifier.height(4.dp))
            }


            // ------------------------------------------------
            // CURRENT ACTIVE MEMBERSHIP
            // ------------------------------------------------
            if (hasActiveMembership) {
                item {

                    Text(
                        text = "CURRENT MEMBERSHIP",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF2196F3),
                        modifier = Modifier.padding(
                            top = 4.dp,
                            bottom = 4.dp
                        )
                    )

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = Color.White
                        )
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp)
                        ) {

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {

                                Box(
                                    modifier = Modifier
                                        .size(46.dp)
                                        .background(
                                            Color(0xFFE8F5E9),
                                            RoundedCornerShape(12.dp)
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.WorkspacePremium,
                                        contentDescription = null,
                                        tint = Color(0xFF16A34A),
                                        modifier = Modifier.size(25.dp)
                                    )
                                }

                                Spacer(
                                    modifier = Modifier.width(12.dp)
                                )

                                Column(
                                    modifier = Modifier.weight(1f)
                                ) {

                                    Text(
                                        text = when {
                                            isAdmin ->
                                                "Admin Membership"

                                            isFreeTrial ->
                                                "1-Day Free Trial"

                                            else ->
                                                currentPlan?.label
                                                    ?: currentPlanId
                                        },
                                        fontSize = 17.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF0F172A)
                                    )

                                    Spacer(
                                        modifier = Modifier.height(2.dp)
                                    )

                                    Text(
                                        text = when {
                                            isAdmin ->
                                                "Full SmartDrivo access"

                                            isFreeTrial ->
                                                "Full SmartDrivo access - Free"

                                            else ->
                                                "₹${if (currentPlanPrice > 0) currentPlanPrice else currentPlan?.price ?: 0} plan"
                                        },                                        fontSize = 12.sp,
                                        color = Color(0xFF64748B)
                                    )
                                }

                                Box(
                                    modifier = Modifier
                                        .background(
                                            Color(0xFFDCFCE7),
                                            RoundedCornerShape(8.dp)
                                        )
                                        .padding(
                                            horizontal = 10.dp,
                                            vertical = 5.dp
                                        )
                                ) {
                                    Text(
                                        text = "● ACTIVE",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF16A34A)
                                    )
                                }
                            }


                            Spacer(
                                modifier = Modifier.height(14.dp)
                            )


                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {

                                Card(
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(12.dp),
                                    colors = CardDefaults.cardColors(
                                        containerColor = Color(0xFFF0F9FF)
                                    )
                                ) {
                                    Column(
                                        modifier = Modifier.padding(12.dp)
                                    ) {
                                        Text(
                                            text = "Remaining",
                                            fontSize = 11.sp,
                                            color = Color(0xFF64748B)
                                        )

                                        Text(
                                            text = when {
                                                isAdmin ->
                                                    "Unlimited"

                                                remainingDays == 1 ->
                                                    "1 Day"

                                                else ->
                                                    "$remainingDays Days"
                                            },
                                            fontSize = 17.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFF0284C7)
                                        )
                                    }
                                }


                                Card(
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(12.dp),
                                    colors = CardDefaults.cardColors(
                                        containerColor = Color(0xFFF8FAFC)
                                    )
                                ) {
                                    Column(
                                        modifier = Modifier.padding(12.dp)
                                    ) {
                                        Text(
                                            text = "Valid Until",
                                            fontSize = 11.sp,
                                            color = Color(0xFF64748B)
                                        )

                                        Text(
                                            text = if (isAdmin)
                                                "No Expiry"
                                            else
                                                expiryText,
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFF0F172A)
                                        )
                                    }
                                }
                            }


                            if (!isAdmin) {
                                Spacer(
                                    modifier = Modifier.height(10.dp)
                                )

                                Text(
                                    text =
                                        if (isFreeTrial)
                                            "Your 1-day free trial includes full SmartDrivo access. After it ends, choose a membership plan to continue."
                                        else
                                            "Your current membership keeps working while a renewal payment is waiting for admin approval.",
                                    fontSize = 11.5.sp,
                                    color = Color(0xFF64748B)
                                )
                            }
                        }
                    }
                }
            }


            // ------------------------------------------------
            // AVAILABLE PLANS
            // ------------------------------------------------
            item {
                Text(
                    text = when {
                        isFreeTrial ->
                            "CHOOSE PLAN FOR AFTER TRIAL"

                        hasActiveMembership ->
                            "RENEW OR CHANGE PLAN"

                        else ->
                            "MEMBERSHIP PLANS"
                    },
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF2196F3),
                    modifier = Modifier.padding(
                        top = 8.dp,
                        bottom = 2.dp
                    )
                )
            }


            items(
                items = plans,
                key = { it.id }
            ) { plan ->

                val isSelected =
                    selectedPlan.id == plan.id

                val isRunningPlan =
                    hasActiveMembership &&
                    !isAdmin &&
                    plan.id == currentPlanId

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(
                            RoundedCornerShape(15.dp)
                        )
                        .border(
                            width = if (isSelected)
                                2.dp
                            else
                                1.dp,
                            color = if (isSelected)
                                Color(0xFF2196F3)
                            else
                                Color(0xFFE2E8F0),
                            shape = RoundedCornerShape(15.dp)
                        )
                        .clickable {
                            selectedPlan = plan
                        },
                    shape = RoundedCornerShape(15.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = Color.White
                    )
                ) {

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {

                        Column(
                            modifier = Modifier.weight(1f)
                        ) {

                            Row(
                                verticalAlignment = Alignment.CenterVertically
                            ) {

                                Text(
                                    text = plan.label,
                                    fontSize = 17.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF0F172A)
                                )


                                if (isRunningPlan) {
                                    Spacer(
                                        modifier = Modifier.width(7.dp)
                                    )

                                    Box(
                                        modifier = Modifier
                                            .background(
                                                Color(0xFFDCFCE7),
                                                RoundedCornerShape(5.dp)
                                            )
                                            .padding(
                                                horizontal = 6.dp,
                                                vertical = 2.dp
                                            )
                                    ) {
                                        Text(
                                            text = "CURRENT",
                                            fontSize = 8.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFF16A34A)
                                        )
                                    }
                                }


                                if (plan.id == "7DAYS") {
                                    Spacer(
                                        modifier = Modifier.width(7.dp)
                                    )

                                    Box(
                                        modifier = Modifier
                                            .background(
                                                Color(0xFFE0F2FE),
                                                RoundedCornerShape(5.dp)
                                            )
                                            .padding(
                                                horizontal = 6.dp,
                                                vertical = 2.dp
                                            )
                                    ) {
                                        Text(
                                            text = "POPULAR",
                                            fontSize = 8.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFF0284C7)
                                        )
                                    }
                                }
                            }


                            Spacer(
                                modifier = Modifier.height(3.dp)
                            )

                            Text(
                                text = "${plan.days} Days SmartDrivo Access",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium,
                                color = Color(0xFF64748B)
                            )

                            if (plan.description.isNotBlank()) {
                                Text(
                                    text = plan.description,
                                    fontSize = 11.5.sp,
                                    color = Color(0xFF64748B)
                                )
                            }
                        }


                        Text(
                            text = "₹${plan.price}",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFF2196F3)
                        )


                        if (isSelected) {
                            Spacer(
                                modifier = Modifier.width(7.dp)
                            )

                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = "Selected",
                                tint = Color(0xFF2196F3),
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }
                }
            }


            item {

                Spacer(
                    modifier = Modifier.height(4.dp)
                )

                Button(
                    onClick = {
                        onPlanSelected(selectedPlan)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF2196F3),
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(13.dp)
                ) {
                    Text(
                        text = if (hasActiveMembership)
                            "Renew ${selectedPlan.label} • ₹${selectedPlan.price}"
                        else
                            "Continue • ₹${selectedPlan.price}",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                }


                Spacer(
                    modifier = Modifier.height(8.dp)
                )

                Text(
                    text = "After payment, enter the 12-digit UTR. Your renewal request will be sent to the SmartDrivo admin for approval.",
                    fontSize = 11.5.sp,
                    color = Color(0xFF64748B),
                    modifier = Modifier.padding(
                        horizontal = 4.dp
                    )
                )

                Spacer(
                    modifier = Modifier.height(10.dp)
                )

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            uriHandler.openUri(
                                "https://t.me/SmartDrivoSupport"
                            )
                        },
                    shape = RoundedCornerShape(13.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = Color(0xFFEFF8FF)
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(
                                horizontal = 14.dp,
                                vertical = 11.dp
                            ),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(
                                text = "Need Help? Telegram Support",
                                fontSize = 12.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF0F172A)
                            )

                            Spacer(
                                modifier = Modifier.height(2.dp)
                            )

                            Text(
                                text = "@SmartDrivoSupport",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFF2196F3)
                            )
                        }

                        Text(
                            text = "Open",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF2196F3)
                        )
                    }
                }

                MembershipBenefitsSection()

                Spacer(
                    modifier = Modifier.height(18.dp)
                )
            }
        }
    }
}

@Composable
private fun MembershipBenefitsSection() {
    Column(
        modifier = Modifier.fillMaxWidth()
    ) {
        Text(
            text = "WHAT YOU GET AFTER ACTIVATION",
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF2196F3)
        )

        Spacer(
            modifier = Modifier.height(4.dp)
        )

        Text(
            text = "Activate any membership plan to unlock full SmartDrivo access.",
            fontSize = 11.5.sp,
            color = Color(0xFF64748B)
        )

        Spacer(
            modifier = Modifier.height(10.dp)
        )

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(15.dp),
            colors = CardDefaults.cardColors(
                containerColor = Color.White
            )
        ) {
            Column(
                modifier = Modifier.padding(
                    horizontal = 14.dp,
                    vertical = 12.dp
                ),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                MembershipBenefitRow(
                    title = "Fast Auto Accept",
                    description = "Quickly accepts matching ride offers using your saved settings."
                )

                MembershipBenefitRow(
                    title = "Fare & Distance Filters",
                    description = "Use minimum fare, maximum pickup, maximum drop and Filter 2 rules."
                )

                MembershipBenefitRow(
                    title = "GO TO & NO GO Areas",
                    description = "Choose preferred destination areas and block unwanted destination areas."
                )

                MembershipBenefitRow(
                    title = "Auto Reject No Match",
                    description = "When enabled, offers that do not match active conditions can be skipped automatically."
                )

                MembershipBenefitRow(
                    title = "Bundle Order Support",
                    description = "Control supported bundle offers together with your normal filters."
                )

                MembershipBenefitRow(
                    title = "Ride History & Accept Speed",
                    description = "See accepted, ignored and rejected ride records with useful order details."
                )
            }
        }
    }
}

@Composable
private fun MembershipBenefitRow(
    title: String,
    description: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.Top
    ) {
        Icon(
            imageVector = Icons.Default.CheckCircle,
            contentDescription = null,
            tint = Color(0xFF2196F3),
            modifier = Modifier.size(19.dp)
        )

        Spacer(
            modifier = Modifier.width(9.dp)
        )

        Column(
            modifier = Modifier.weight(1f)
        ) {
            Text(
                text = title,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF0F172A)
            )

            Spacer(
                modifier = Modifier.height(1.dp)
            )

            Text(
                text = description,
                fontSize = 10.5.sp,
                color = Color(0xFF64748B)
            )
        }
    }
}
