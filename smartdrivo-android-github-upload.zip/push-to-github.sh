#!/data/data/com.termux/files/usr/bin/bash
set -e
echo "SmartDrivo project -> GitHub"
if [ ! -f "settings.gradle.kts" ] && [ ! -f "settings.gradle" ]; then
  echo "Android project root-ல் இல்லை. settings.gradle(.kts) உள்ள folder-க்கு cd செய்து மீண்டும் இயக்கவும்."
  exit 1
fi
read -r -p "GitHub repository HTTPS URL: " REPO_URL
if [ -z "$REPO_URL" ]; then echo "Repository URL காலியாக உள்ளது."; exit 1; fi
if [ ! -d ".git" ]; then git init; fi
git add .
if ! git diff --cached --quiet; then
  git commit -m "Upload Android project from phone"
else
  echo "புதிய commit செய்ய வேண்டிய மாற்றங்கள் இல்லை."
fi
git branch -M main
if git remote get-url origin >/dev/null 2>&1; then
  git remote set-url origin "$REPO_URL"
else
  git remote add origin "$REPO_URL"
fi
git push -u origin main
echo "Push முடிந்தது. GitHub repository-ஐ refresh செய்து கோப்புகளைச் சரிபார்க்கவும்."
